

<?php $__env->startSection('content'); ?>

	<div><li><a href="#">
		Title: <?php echo e($card->title); ?><br />
		created: <?php echo e($card->created_at); ?><br /></a>
	</li></div>	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>