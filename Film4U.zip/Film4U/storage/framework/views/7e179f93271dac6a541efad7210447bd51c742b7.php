

<?php $__env->startSection('content'); ?>
<div>
	<h1>Content of movie <?php echo e($movie); ?></h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainPageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>