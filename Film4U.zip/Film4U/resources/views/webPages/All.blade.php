@extends('layouts.mainPageLayout')
@section('content')
<!--enter content-->

@stop