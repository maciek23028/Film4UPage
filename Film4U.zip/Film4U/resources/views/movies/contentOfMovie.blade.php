@extends('layouts.mainPageLayout')

@section('content')
<div>
	<h1>Content of movie {{$movie}}</h1>
</div>
@stop
